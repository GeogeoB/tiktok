import React,  { useEffect, useRef, useState } from 'react';
import VideoItems from './videoItems';

function Video({info, animationSlide}) {
    let className = "videoContainer ";
    const videoRef = useRef(null);

    useEffect(() => {
        if(videoRef && info.play) {
            videoRef.current.play();
        } else if (videoRef) {
            videoRef.current.pause();
        }
    }, [videoRef, info]);

    useEffect(() => {
        if(videoRef) {
            videoRef.current.addEventListener('ended', function() {
                animationSlide(-2*window.innerHeight + "px", "Up");
            });
        }

        return () => {
            document.removeEventListener('ended', function() {
                animationSlide(-2*window.innerHeight + "px", "Up");
            });
          }; 
    }, [])

    return (
        <div className={className}>
            <div className="blur"></div>
            <VideoItems></VideoItems>
            <div className="carree"></div>
            <img src={info.src + ".PNG"} className="imageVideo" draggable="false"/>
            {videoRef && <video ref={videoRef} src={info.src + ".mp4"} className='video' controls></video>}
        </div>
    )
}

export default Video;