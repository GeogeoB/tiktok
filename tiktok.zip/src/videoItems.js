import React,  { useEffect, useRef, useState } from 'react';

function VideoItems() {
    return (
        <div className="videoItems">
            <div className="items">
                <div className="circle"></div>
            </div>
            <div className="items">
                
            </div>
            <div className="items">

            </div>
            <div className="items">

            </div>
        </div>
    )
}

export default VideoItems